const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

async function requestGemini(model, apiKey, payload) {
  const response = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`,
    {
      method: "POST",
      headers: {
        "x-goog-api-key": apiKey,
        "Content-Type": "application/json"
      },
      body: JSON.stringify(payload)
    }
  );
  const data = await response.json().catch(() => ({}));
  return { response, data };
}

exports.handler = async (event) => {
  const headers = { "Content-Type": "application/json" };
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, headers, body: JSON.stringify({ error: "Method not allowed" }) };
  }

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return { statusCode: 503, headers, body: JSON.stringify({ error: "Gemini is not configured. Add GEMINI_API_KEY in Netlify environment variables, then redeploy." }) };
  }

  try {
    const body = JSON.parse(event.body || "{}");
    const messages = Array.isArray(body.messages) ? body.messages : [];
    const contents = messages
      .filter(m => m && ["user", "assistant"].includes(m.role) && typeof m.content === "string")
      .slice(-16)
      .map(m => ({
        role: m.role === "assistant" ? "model" : "user",
        parts: [{ text: m.content.slice(0, 6000) }]
      }));

    if (!contents.length) {
      return { statusCode: 400, headers, body: JSON.stringify({ error: "Please enter a message and try again." }) };
    }

    const payload = {
      systemInstruction: {
        parts: [{ text: "You are Bilal Abid AI, a helpful, friendly assistant. Answer clearly and accurately. If unsure, say so. Do not claim you can answer literally every question." }]
      },
      contents,
      generationConfig: { temperature: 0.7, maxOutputTokens: 2048 }
    };

    // Try the primary model twice for temporary capacity/rate-limit/server errors.
    // If it remains unavailable, switch to a smaller supported Flash-Lite model.
    const models = ["gemini-3.8-flash", "gemini-3.5-flash-lite"];
    let lastStatus = 503;
    let lastMessage = "Gemini is temporarily busy. Please try again shortly.";

    for (let modelIndex = 0; modelIndex < models.length; modelIndex++) {
      const model = models[modelIndex];
      const attempts = 2;

      for (let attempt = 0; attempt < attempts; attempt++) {
        let result;
        try {
          result = await requestGemini(model, apiKey, payload);
        } catch (networkError) {
          lastStatus = 503;
          lastMessage = "Could not reach Gemini right now. Please try again shortly.";
          if (attempt < attempts - 1) {
            await sleep(700 * (attempt + 1));
            continue;
          }
          break;
        }

        const { response, data } = result;
        if (response.ok) {
          const answer = (data.candidates?.[0]?.content?.parts || [])
            .map(part => part.text || "")
            .join("")
            .trim();
          if (answer) {
            return { statusCode: 200, headers, body: JSON.stringify({ answer }) };
          }
          lastStatus = 502;
          lastMessage = "Gemini returned an empty response. Please try again.";
          break;
        }

        lastStatus = response.status;
        lastMessage = data.error?.message || "Gemini returned an error.";

        // Authentication, invalid request, and other permanent errors won't improve by retrying.
        const temporary = [429, 500, 502, 503, 504].includes(response.status);
        if (!temporary) {
          return { statusCode: response.status, headers, body: JSON.stringify({ error: lastMessage }) };
        }

        if (attempt < attempts - 1) await sleep(700 * (attempt + 1));
      }
      // Move to the fallback only after the primary model has failed transiently.
    }

    return {
      statusCode: lastStatus >= 500 ? 503 : lastStatus,
      headers,
      body: JSON.stringify({
        error: "Gemini is busy or temporarily unavailable on both models. Please try again in a little while. Details: " + lastMessage
      })
    };
  } catch (error) {
    return { statusCode: 500, headers, body: JSON.stringify({ error: "Something went wrong while contacting Gemini. Please try again." }) };
  }
};
